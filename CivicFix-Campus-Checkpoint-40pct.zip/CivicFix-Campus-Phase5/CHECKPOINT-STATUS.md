# CivicFix Campus — Review 1 Checkpoint (~40% scope)

This is a deliberately reduced checkpoint build of CivicFix Campus,
scoped to represent an early-stage submission. It contains a working
core loop only. Everything else described in the full project vision is
explicitly out of scope for this checkpoint and listed below.

## What this checkpoint includes (built and verified)

| Feature | Status |
|---|---|
| Student login (JWT auth) | Working |
| Submit a report: category, location, description, photo upload | Working |
| Image validation (type, size) | Working |
| AI analysis (mock provider): severity, confidence, safety risk, people affected, recommended action | Working |
| Student dashboard: totals, recent reports list | Working |
| Backend test suite | **5/5 passing** |
| Frontend production build | Succeeds |

Demo login: `student@civicfix.edu` / `Student@123`
(`admin@civicfix.edu` / `Admin@123` also logs in but currently sees the
same student view — admin-specific screens are out of scope below.)

## Explicitly NOT in this checkpoint (planned for later phases)

- Admin priority queue, report assignment, status/resolution workflow
- Duplicate report detection and "support this report"
- Explainable priority scoring engine (weighted 0–100 score breakdown)
- Campus map (Leaflet) and analytics dashboards (category/location/trend charts)
- Recurring-problem prediction
- Multi-campus data isolation
- Real Gemini vision AI (currently a deterministic mock provider that
  does not look at the photo — clearly labelled as such in the UI)
- Persistent cloud image storage
- Production deployment (Vercel/Render/MongoDB Atlas)

## Why it's scoped this way

This is the smallest end-to-end slice that proves the core mechanism
works: a student can authenticate, submit a report with a photo, have it
analysed, and see it reflected on their dashboard. Every feature above is
an extension of this same pipeline, not a redesign of it — the next
checkpoint builds outward from here rather than replacing anything.

## Honesty note

An earlier, more complete version of this project (with all the features
listed above) already exists in a separate branch of my work. This
checkpoint intentionally represents an earlier state so the review
reflects incremental progress rather than a finished project submitted
all at once. Nothing here is understated or overstated — every item
marked "Working" above passed an automated test or a manual build check
on the date this file was written.

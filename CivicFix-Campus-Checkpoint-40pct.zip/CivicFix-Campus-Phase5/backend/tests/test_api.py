from io import BytesIO
from fastapi.testclient import TestClient
from app.main import app


def login(client):
    response = client.post("/auth/login", json={"email": "student@civicfix.edu", "password": "Student@123"})
    assert response.status_code == 200
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def test_health_and_login():
    with TestClient(app) as client:
        assert client.get("/health").json()["status"] == "ok"
        assert client.post("/auth/login", json={"email": "student@civicfix.edu", "password": "wrong-password"}).status_code == 401
        assert login(client)["Authorization"].startswith("Bearer ")


def test_submit_and_list_report():
    with TestClient(app) as client:
        headers = login(client)
        response = client.post("/reports", headers=headers, data={
            "description": "Large pothole outside the library entrance.", "category": "Pothole", "location_name": "Central Library",
        }, files={"image": ("pothole.png", BytesIO(b"fake image bytes"), "image/png")})
        assert response.status_code == 201
        assert response.json()["status"] == "AI Verified"
        assert response.json()["ai_provider"] == "mock-explainable-v1"
        assert response.json()["severity"] is not None
        assert client.get("/reports", headers=headers).status_code == 200


def test_analysis_reflects_urgency_language():
    with TestClient(app) as client:
        headers = login(client)
        report = client.post("/reports", headers=headers, data={
            "description": "A deep pothole is dangerous at night and could cause an accident.", "category": "Pothole", "location_name": "Main Library",
        }, files={"image": ("pothole.png", BytesIO(b"fake image bytes"), "image/png")}).json()
        assert report["severity"] >= 7


def test_dashboard_counts():
    with TestClient(app) as client:
        headers = login(client)
        client.post("/reports", headers=headers, data={"description": "Overflowing waste bin beside the canteen entrance.", "category": "Garbage overflow", "location_name": "Canteen"}, files={"image": ("g.png", BytesIO(b"image"), "image/png")})
        dashboard = client.get("/dashboard", headers=headers).json()
        assert dashboard["total_reports"] >= 1
        assert len(dashboard["recent_reports"]) >= 1


def test_rejects_unauthorized_and_invalid_file():
    with TestClient(app) as client:
        assert client.get("/reports").status_code == 403
        response = client.post("/reports", headers=login(client), data={
            "description": "A broken light on the east pathway.", "category": "Broken streetlight", "location_name": "East Path",
        }, files={"image": ("invalid.pdf", BytesIO(b"no"), "application/pdf")})
        assert response.status_code == 415

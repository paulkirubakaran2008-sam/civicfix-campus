from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4
from motor.motor_asyncio import AsyncIOMotorClient
from .config import get_settings


class ReportRepository:
    def __init__(self):
        self.memory: list[dict] = []
        self.client = None
        self.collection = None

    async def connect(self):
        settings = get_settings()
        if settings.mongodb_url:
            self.client = AsyncIOMotorClient(settings.mongodb_url, serverSelectionTimeoutMS=1500)
            await self.client.admin.command("ping")
            self.collection = self.client[settings.mongodb_db].reports

    async def close(self):
        if self.client:
            self.client.close()

    async def create(self, data: dict) -> dict:
        record = {**data, "id": str(uuid4()), "report_id": f"CF-{str(uuid4().int)[-6:]}", "status": "AI Verified", "created_at": datetime.now(UTC)}
        if self.collection is not None:
            await self.collection.insert_one(record.copy())
        else:
            self.memory.append(record)
        return record

    async def for_user(self, user_id: str, is_admin: bool = False) -> list[dict]:
        if self.collection is not None:
            query = {} if is_admin else {"user_id": user_id}
            return await self.collection.find(query, {"_id": 0}).sort("created_at", -1).to_list(length=100)
        reports = self.memory if is_admin else [r for r in self.memory if r["user_id"] == user_id]
        return sorted(reports, key=lambda r: r["created_at"], reverse=True)


repository = ReportRepository()


def upload_path(filename: str) -> Path:
    folder = Path(get_settings().upload_dir)
    folder.mkdir(parents=True, exist_ok=True)
    return folder / filename

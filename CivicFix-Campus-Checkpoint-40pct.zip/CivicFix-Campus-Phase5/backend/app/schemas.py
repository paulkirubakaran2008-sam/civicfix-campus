from datetime import datetime
from typing import Literal
from pydantic import BaseModel, EmailStr, Field


Category = Literal["Garbage overflow", "Pothole", "Water leakage", "Broken streetlight", "Damaged infrastructure", "Other"]
Status = Literal["Reported", "AI Verified"]


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class UserPublic(BaseModel):
    id: str
    name: str
    email: EmailStr
    role: Literal["student", "admin"]


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserPublic


class ReportPublic(BaseModel):
    id: str
    report_id: str
    user_id: str
    reporter_name: str
    image_url: str | None = None
    description: str
    category: Category
    location_name: str
    latitude: float | None = None
    longitude: float | None = None
    status: Status
    ai_provider: str | None = None
    ai_confidence: float | None = None
    severity: float | None = None
    safety_risk: Literal["Low", "Medium", "High"] | None = None
    people_affected: int | None = None
    recommended_action: str | None = None
    created_at: datetime


class DashboardResponse(BaseModel):
    total_reports: int
    pending_reports: int
    resolved_reports: int
    recent_reports: list[ReportPublic]

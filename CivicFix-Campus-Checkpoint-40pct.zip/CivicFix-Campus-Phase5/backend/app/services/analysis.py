"""Phase 1 analysis contract.

This is a transparent, deterministic development fallback -- it does NOT
look at the uploaded image. It uses the selected category and simple
keyword checks on the report text to produce a plausible severity,
confidence, safety risk, and recommended action. It exists so the report
pipeline (upload -> analyze -> store -> display) is fully working end to
end before a real vision model is connected in a later phase.
"""
from dataclasses import dataclass

MOCK_PROVIDER = "mock-explainable-v1"


@dataclass
class AnalysisResult:
    detected_category: str
    confidence: float
    severity: float
    safety_risk: str
    people_affected: int
    recommended_action: str
    provider: str


class MockVisionAnalysisService:
    profiles = {
        "Garbage overflow": (5.8, 62, "Medium", "Arrange waste collection and clean the affected area."),
        "Pothole": (7.4, 76, "High", "Inspect and repair the road surface; mark the hazard until repaired."),
        "Water leakage": (6.7, 71, "Medium", "Inspect the source, isolate the leak, and repair the pipe or fixture."),
        "Broken streetlight": (6.5, 74, "High", "Inspect the electrical connection and replace the damaged light fitting."),
        "Damaged infrastructure": (7.1, 73, "High", "Inspect the structure, secure the area, and schedule repair."),
        "Other": (4.8, 55, "Low", "Inspect the reported area and determine the appropriate maintenance action."),
    }
    urgent_words = ("danger", "accident", "injury", "urgent", "large", "flood", "exposed", "night", "deep")

    def analyze(self, category: str, description: str, location_name: str) -> AnalysisResult:
        base_severity, confidence, risk, action = self.profiles[category]
        text = description.lower()
        urgency = sum(word in text for word in self.urgent_words)
        severity = min(10.0, round(base_severity + urgency * 0.45, 1))
        confidence = min(96.0, round(confidence + min(len(description) // 80, 8), 1))
        if severity >= 7.0:
            risk = "High"
        elif severity >= 5.5:
            risk = "Medium"
        else:
            risk = "Low"
        people = 90 if any(word in location_name.lower() for word in ("library", "canteen", "main", "hostel")) else 45
        people += urgency * 10
        return AnalysisResult(
            detected_category=category, confidence=confidence, severity=severity, safety_risk=risk,
            people_affected=people, recommended_action=action, provider=MOCK_PROVIDER,
        )


analysis_service = MockVisionAnalysisService()

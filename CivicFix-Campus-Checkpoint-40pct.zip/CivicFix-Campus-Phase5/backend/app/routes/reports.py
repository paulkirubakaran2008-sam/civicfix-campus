from uuid import uuid4
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from ..auth import get_current_user
from ..repository import repository, upload_path
from ..schemas import DashboardResponse, ReportPublic, UserPublic
from ..services.analysis import analysis_service

router = APIRouter(tags=["reports"])
ALLOWED_TYPES = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
MAX_FILE_SIZE = 5 * 1024 * 1024


def serialise(report: dict) -> ReportPublic:
    return ReportPublic(**report)


@router.post("/reports", response_model=ReportPublic, status_code=status.HTTP_201_CREATED)
async def create_report(
    description: str = Form(..., min_length=10, max_length=1000),
    category: str = Form(...),
    location_name: str = Form(..., min_length=2, max_length=120),
    latitude: float | None = Form(None),
    longitude: float | None = Form(None),
    image: UploadFile = File(...),
    user: UserPublic = Depends(get_current_user),
):
    if category not in {"Garbage overflow", "Pothole", "Water leakage", "Broken streetlight", "Damaged infrastructure", "Other"}:
        raise HTTPException(status_code=422, detail="Choose a valid problem category")
    if image.content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=415, detail="Upload a JPEG, PNG, or WebP image")
    content = await image.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="Image must be 5 MB or smaller")
    filename = f"{uuid4()}{ALLOWED_TYPES[image.content_type]}"
    upload_path(filename).write_bytes(content)

    analysis = analysis_service.analyze(category, description, location_name)
    report = await repository.create({
        "user_id": user.id, "reporter_name": user.name, "image_url": f"/uploads/{filename}",
        "description": description.strip(), "category": category, "location_name": location_name.strip(),
        "latitude": latitude, "longitude": longitude,
        "ai_provider": analysis.provider, "ai_confidence": analysis.confidence, "severity": analysis.severity,
        "safety_risk": analysis.safety_risk, "people_affected": analysis.people_affected,
        "recommended_action": analysis.recommended_action,
    })
    return serialise(report)


@router.get("/reports", response_model=list[ReportPublic])
async def list_reports(user: UserPublic = Depends(get_current_user)):
    reports = await repository.for_user(user.id, user.role == "admin")
    return [serialise(report) for report in reports]


@router.get("/dashboard", response_model=DashboardResponse)
async def dashboard(user: UserPublic = Depends(get_current_user)):
    reports = await repository.for_user(user.id, user.role == "admin")
    return DashboardResponse(
        total_reports=len(reports),
        pending_reports=len(reports),
        resolved_reports=0,
        recent_reports=[serialise(r) for r in reports[:5]],
    )

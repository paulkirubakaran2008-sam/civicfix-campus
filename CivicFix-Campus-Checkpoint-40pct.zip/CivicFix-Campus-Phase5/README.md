# CivicFix Campus — Review 1 Checkpoint

**Report. Prioritize. Resolve. Improve.**

This is an early checkpoint build. See **CHECKPOINT-STATUS.md** for exactly
what is and isn't included at this stage — read that first.

## What this is

A student can log in, submit a campus maintenance report with a photo, get
an AI analysis of it (severity, safety risk, recommended action), and see
it on their dashboard. That loop is fully working and tested.

Admin workflows, the priority-scoring engine, duplicate detection, maps,
analytics, predictions, real Gemini AI, multi-campus support, and
deployment are intentionally out of scope for this checkpoint — see
CHECKPOINT-STATUS.md for the full list and reasoning.

## Run locally

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
cp .env.example .env             # Windows: Copy-Item .env.example .env
uvicorn app.main:app --reload --reload-dir app --port 8000
```

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. Demo login: `student@civicfix.edu` /
`Student@123`.

## Run tests

```bash
cd backend
source .venv/bin/activate
pytest
```

Expect `5 passed`.
